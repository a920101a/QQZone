class HttpConfig {
  static const String baseURL = "https://httpbin.org";
  static const int timeout = 5000;
}