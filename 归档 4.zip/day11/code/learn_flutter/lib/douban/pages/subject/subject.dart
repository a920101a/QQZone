import 'package:flutter/material.dart';

class HYSubjectPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("书影音"),
      ),
      body: Text("书影音"),
    );
  }
}
