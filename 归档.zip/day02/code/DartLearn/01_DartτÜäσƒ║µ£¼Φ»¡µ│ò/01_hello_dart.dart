/**
 * 1.main函数是dart入口
 * 2.dart当中打印信息使用print函数
 */

main(List<String> args) {
  // List<String> args -> 列表<String> - 泛型
  print("Hello World");
}
