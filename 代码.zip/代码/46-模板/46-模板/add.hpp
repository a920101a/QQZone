﻿#pragma once

template <typename T>
T add(T a, T b) {
	return a + b;
}