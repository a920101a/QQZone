﻿#pragma once

void test();