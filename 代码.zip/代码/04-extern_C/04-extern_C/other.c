﻿
#include "math.h"
#include <stdio.h>

void other() {
	printf("other - %d\n", sum(10, 20));
}