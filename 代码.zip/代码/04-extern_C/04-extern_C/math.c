﻿
#include "math.h"

// _sum
int sum(int v1, int v2) {
	return v1 + v2;
}

// _delta
int delta(int v1, int v2) {
	return v1 - v2;
}

int divide(int v1, int v2) {
	return v1 / v2;
}