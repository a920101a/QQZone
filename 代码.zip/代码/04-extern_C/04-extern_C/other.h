﻿#pragma once

void other1();

#ifndef __OTHER_H
#define __OTHER_H

void other2();

#endif // !__OTHER_H
