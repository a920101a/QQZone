﻿#pragma once

namespace MJ {
	class Person {
	public:
		Person();
		~Person();
	};
}

