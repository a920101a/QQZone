﻿#include "Person.h"
// using namespace MJ;

namespace MJ {
	Person::Person() {}
	Person::~Person() {}
}
