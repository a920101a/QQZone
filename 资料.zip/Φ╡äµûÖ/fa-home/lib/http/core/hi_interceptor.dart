import 'package:flutter_bili_app/http/core/hi_error.dart';

///错误处理拦截器
typedef HiErrorInterceptor(HiNetError error);
