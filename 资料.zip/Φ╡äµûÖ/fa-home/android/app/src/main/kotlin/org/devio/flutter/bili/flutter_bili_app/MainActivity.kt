package org.devio.flutter.bili.flutter_bili_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
