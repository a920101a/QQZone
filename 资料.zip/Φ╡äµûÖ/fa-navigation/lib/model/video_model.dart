class VideoModel {
  int vid;

  VideoModel(this.vid);
}
